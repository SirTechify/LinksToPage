from flask import Flask, render_template

def create_app():
    app = Flask(__name__)

    @app.route('/')
    def home():
        # Pass your social links to the template
        return render_template('index.html', 
                               github_url="https://github.com/your-github-username", 
                               instagram_url="https://instagram.com/your-instagram-username")

    return app